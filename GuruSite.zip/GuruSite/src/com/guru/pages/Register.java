package com.guru.pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Register {
	WebDriver driver;
	public Register(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void clickRegister()
	{
		driver.findElement(By.linkText("REGISTER")).click();
	}
	
	public void registerUser(Map<Object, Object> map)
	{
		WebElement FirstName = driver.findElement(By.cssSelector("input[name='firstName']"));
		FirstName.sendKeys(map.get("First_Name").toString());
		WebElement LastName = driver.findElement(By.cssSelector("input[name='lastName']"));
		LastName.sendKeys(map.get("Last_Name").toString());
		WebElement Phone = driver.findElement(By.cssSelector("input[name='phone']"));
		Phone.sendKeys(map.get("Phone").toString());
		WebElement Email = driver.findElement(By.cssSelector("input[name='userName']"));
		Email.sendKeys(map.get("Email").toString());
		WebElement Address = driver.findElement(By.cssSelector("input[name='address1']"));
		Address.sendKeys(map.get("Address").toString());
		WebElement City = driver.findElement(By.cssSelector("input[name='city']"));
		City.sendKeys(map.get("City").toString());
		WebElement State = driver.findElement(By.cssSelector("input[name='state']"));
		State.sendKeys(map.get("State").toString());
		WebElement Pincode = driver.findElement(By.cssSelector("input[name='postalCode']"));
		Pincode.sendKeys(map.get("Postal_Code").toString());
		WebElement Country = driver.findElement(By.cssSelector("select[name='country']"));
		Select select = new Select(Country);
		select.selectByValue(map.get("Country").toString());
		WebElement UserName = driver.findElement(By.cssSelector("input[name='email']"));
		UserName.sendKeys(map.get("User_Name").toString());
		WebElement Password = driver.findElement(By.cssSelector("input[name='password']"));
		Password.sendKeys(map.get("Password").toString());
		WebElement ConfirmPassword = driver.findElement(By.cssSelector("input[name='confirmPassword']"));
		ConfirmPassword.sendKeys(map.get("Confirm_Password").toString());
		WebElement submitButton = driver.findElement(By.cssSelector("input[name='submit']"));
		submitButton.click();
	}
}
