package com.guru.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {
	WebDriver driver;
	public Login(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void loginUser(String userName, String password)
	{
		driver.findElement(By.cssSelector("input[name=userName]")).sendKeys(userName);
		driver.findElement(By.cssSelector("input[name=password]")).sendKeys(password);
		driver.findElement(By.cssSelector("input[name=submit]")).click();
	}
}
