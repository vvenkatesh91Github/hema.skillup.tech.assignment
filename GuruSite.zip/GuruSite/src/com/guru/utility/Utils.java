package com.guru.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

public class Utils {

	public static Object[] LAST_EXCEL_DATA;
	public static Object[] readExcelFile(String filePath) throws IOException
	{
		FileInputStream file = new FileInputStream(filePath);
		XSSFWorkbook workbook  = new XSSFWorkbook(file);
		Object[] obj = null;
		
		for(int i = 0; i < workbook.getNumberOfSheets(); i++)
		{
			XSSFSheet sheet = workbook.getSheetAt(i);
			int rowSize = sheet.getLastRowNum();
			obj = new Object[rowSize];
			int columnSize = sheet.getRow(0).getLastCellNum();
			String[] columnHeader = new String[columnSize];
			for(int j = 0; j < columnSize; j++)
			{
				columnHeader[j] = sheet.getRow(0).getCell(j).toString();
			}
			for(int k = 1; k <= rowSize; k++)
			{
				Map<Object, Object> TestData = new HashMap<>();
				for(int cell = 0; cell < columnSize; cell++)
				{
					TestData.put(columnHeader[cell], sheet.getRow(k).getCell(cell).toString());
				}
				obj[k-1] = TestData;
			}
		}
		LAST_EXCEL_DATA = obj;
		return obj;
	}
	
	public static void takeScreenShot(WebDriver driver, ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); 
			FileUtils.copyFile(scrFile, new File("C:\\Users\\hemamv\\Desktop\\errorScreenshots\\" + testResult.getName() +  ".jpg"));
		} 
	}
}
