package com.guru.test;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.guru.pages.Login;
import com.guru.utility.Utils;

public class TestLogin {
public WebDriver driver;
	
	public TestLogin()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hemamv\\Downloads\\seleniumJars\\chromedriver.exe");
	}
	
	@BeforeMethod
	public void browser()
	{
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/newtours/login.php");
	}
	
	@Test(dataProvider = "excel")
	public void testLogin(Map<Object, Object> map)
	{
		Login userLogin = new Login(driver);
		userLogin.loginUser(map.get("User_Name").toString(), map.get("Password").toString());
		
		Assert.assertEquals(driver.findElement(By.cssSelector("div.container-fluid + div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) table table tr:nth-child(1) h3")),
				"Login Successfully", "Unable to login for " + map.get("User_Name").toString());
	}
	
	@DataProvider
	public Object[] excel() throws Exception
	{
		return Utils.LAST_EXCEL_DATA;
	}
	
	@AfterMethod 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		Utils.takeScreenShot(driver, testResult);
		driver.quit();
	}
	
	@AfterClass
	public void afterClass() {
//		driver.quit();
	}
}
