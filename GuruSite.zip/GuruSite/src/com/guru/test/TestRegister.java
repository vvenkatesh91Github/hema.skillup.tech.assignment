package com.guru.test;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.guru.pages.Register;
import com.guru.utility.Utils;

public class TestRegister
{
	public WebDriver driver;
	
	public TestRegister()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hemamv\\Downloads\\seleniumJars\\chromedriver.exe");
	}
	
	@BeforeMethod
	public void browser()
	{
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/newtours/login.php");
	}
	
	@Test(dataProvider = "excel")
	public void testRegister(Map<Object, Object> map)
	{
		Assert.assertTrue(driver.findElement(By.linkText("REGISTER")).isDisplayed(), "Unable to find register link");
		Register register = new Register(driver);
		
		register.clickRegister();
		register.registerUser(map);
		
		Assert.assertEquals(driver.findElement(By.cssSelector("div.container-fluid + div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) table tr:nth-child(3) p:nth-child(3) b")).getText().trim(),
				"Note: Your user name is " + map.get("User_Name").toString(), "Register failed for user name " + map.get("User_Name").toString());
	}
	
	@DataProvider
	public Object[] excel() throws Exception
	{
		return Utils.readExcelFile("C:\\Users\\hemamv\\Desktop\\credentials.xlsx");
	}
	
	@AfterMethod 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		Utils.takeScreenShot(driver, testResult);
		driver.quit();
	}
	
	@AfterClass
	public void afterClass() {
//		driver.quit();
	}
	
	@AfterSuite
	public void afterSuite() {
		Utils.LAST_EXCEL_DATA = null;
	}
}
